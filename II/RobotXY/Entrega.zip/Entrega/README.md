Para iniciar el control del robot del XY se necesitará realizar varios procesos:

 - En primer lugar, cargar el robot XY con el código en el directorio './main/'

 - En segundo lugar, iniciar el servidor python para poder acceder a través de servicio web*. 
Para ello se deberá de ejecutar el comando:
	- 'python3.5 ./python/serverPython.py'
 * Se deberá tener instalado los paquetes de pyserial y flask de python3.

 - En último lugar, instalar el APK en el móvil, y colocar la IP correspondiente del servidor 
python.
